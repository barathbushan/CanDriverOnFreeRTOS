var NAVTREE =
[
  [ "FreeRTOS API Reference", "index.html", [
    [ "Main Page", "index.html", null ],
    [ "Modules", "modules.html", [
      [ "Task Creation", "group___tasks.html", [
        [ "xTaskHandle", "group___tasks.html#xTaskHandle", null ],
        [ "xTaskCreate", "group___tasks.html#xTaskCreate", null ],
        [ "vTaskDelete", "group___tasks.html#vTaskDelete", null ]
      ] ],
      [ "Task Control", "group___task_ctrl.html", [
        [ "vTaskDelay", "group___task_ctrl.html#vTaskDelay", null ],
        [ "vTaskDelayUntil", "group___task_ctrl.html#vTaskDelayUntil", null ],
        [ "uxTaskPriorityGet", "group___task_ctrl.html#uxTaskPriorityGet", null ],
        [ "vTaskPrioritySet", "group___task_ctrl.html#vTaskPrioritySet", null ],
        [ "vTaskSuspend", "group___task_ctrl.html#vTaskSuspend", null ],
        [ "vTaskResume", "group___task_ctrl.html#vTaskResume", null ],
        [ "vTaskResumeFromISR", "group___task_ctrl.html#vTaskResumeFromISR", null ]
      ] ],
      [ "Task Utilities", "group___task_utils.html", [
        [ "xTaskGetTickCount", "group___task_utils.html#xTaskGetTickCount", null ],
        [ "xTaskGetTickCountFromISR", "group___task_utils.html#xTaskGetTickCountFromISR", null ],
        [ "uxTaskGetNumberOfTasks", "group___task_utils.html#uxTaskGetNumberOfTasks", null ],
        [ "vTaskList", "group___task_utils.html#vTaskList", null ],
        [ "vTaskGetRunTimeStats", "group___task_utils.html#vTaskGetRunTimeStats", null ],
        [ "vTaskStartTrace", "group___task_utils.html#vTaskStartTrace", null ],
        [ "usTaskEndTrace", "group___task_utils.html#usTaskEndTrace", null ],
        [ "uxTaskGetStackHighWaterMark", "group___task_utils.html#uxTaskGetStackHighWaterMark", null ],
        [ "xTaskCallApplicationTaskHook", "group___task_utils.html#xTaskCallApplicationTaskHook", null ]
      ] ],
      [ "Kernel Control", "group___kernel_control.html", [
        [ "taskYIELD", "group___kernel_control.html#taskYIELD", null ],
        [ "taskENTER_CRITICAL", "group___kernel_control.html#taskENTER_CRITICAL", null ],
        [ "taskEXIT_CRITICAL", "group___kernel_control.html#taskEXIT_CRITICAL", null ],
        [ "taskDISABLE_INTERRUPTS", "group___kernel_control.html#taskDISABLE_INTERRUPTS", null ],
        [ "taskENABLE_INTERRUPTS", "group___kernel_control.html#taskENABLE_INTERRUPTS", null ],
        [ "vTaskStartScheduler", "group___kernel_control.html#vTaskStartScheduler", null ],
        [ "vTaskEndScheduler", "group___kernel_control.html#vTaskEndScheduler", null ],
        [ "vTaskSuspendAll", "group___kernel_control.html#vTaskSuspendAll", null ],
        [ "xTaskResumeAll", "group___kernel_control.html#xTaskResumeAll", null ]
      ] ],
      [ "FreeRTOS-MPU Specific", "group___m_p_u_specific.html", [
        [ "xTaskCreateRestricted", "group___m_p_u_specific.html#xTaskCreateRestricted", null ],
        [ "vTaskAllocateMPURegions", "group___m_p_u_specific.html#vTaskAllocateMPURegions", null ]
      ] ],
      [ "Queues", "group___queue_management.html", [
        [ "xQueueCreate", "group___queue_management.html#xQueueCreate", null ],
        [ "xQueueSendToFront", "group___queue_management.html#xQueueSendToFront", null ],
        [ "xQueueSendToBack", "group___queue_management.html#xQueueSendToBack", null ],
        [ "xQueueSend", "group___queue_management.html#xQueueSend", null ],
        [ "xQueueGenericSend", "group___queue_management.html#xQueueGenericSend", null ],
        [ "xQueuePeek", "group___queue_management.html#xQueuePeek", null ],
        [ "xQueueReceive", "group___queue_management.html#xQueueReceive", null ],
        [ "xQueueGenericReceive", "group___queue_management.html#xQueueGenericReceive", null ],
        [ "uxQueueMessagesWaiting", "group___queue_management.html#uxQueueMessagesWaiting", null ],
        [ "vQueueDelete", "group___queue_management.html#vQueueDelete", null ],
        [ "xQueueSendToFrontFromISR", "group___queue_management.html#xQueueSendToFrontFromISR", null ],
        [ "xQueueSendToBackFromISR", "group___queue_management.html#xQueueSendToBackFromISR", null ],
        [ "xQueueSendFromISR", "group___queue_management.html#xQueueSendFromISR", null ],
        [ "xQueueGenericSendFromISR", "group___queue_management.html#xQueueGenericSendFromISR", null ],
        [ "xQueueReceiveFromISR", "group___queue_management.html#xQueueReceiveFromISR", null ]
      ] ],
      [ "Semaphore / Mutexes", "group___semaphores.html", [
        [ "vSemaphoreCreateBinary", "group___semaphores.html#vSemaphoreCreateBinary", null ],
        [ "xSemaphoreTake", "group___semaphores.html#xSemaphoreTake", null ],
        [ "xSemaphoreTakeRecursive", "group___semaphores.html#xSemaphoreTakeRecursive", null ],
        [ "xSemaphoreGive", "group___semaphores.html#xSemaphoreGive", null ],
        [ "xSemaphoreGiveRecursive", "group___semaphores.html#xSemaphoreGiveRecursive", null ],
        [ "xSemaphoreGiveFromISR", "group___semaphores.html#xSemaphoreGiveFromISR", null ],
        [ "vSemaphoreCreateMutex", "group___semaphores.html#vSemaphoreCreateMutex", null ],
        [ "xSemaphoreCreateCounting", "group___semaphores.html#xSemaphoreCreateCounting", null ]
      ] ],
      [ "Software Timers", "group___timer.html", [
        [ "xTimerCreate", "group___timer.html#xTimerCreate", null ],
        [ "pvTimerGetTimerID", "group___timer.html#pvTimerGetTimerID", null ],
        [ "xTimerIsTimerActive", "group___timer.html#xTimerIsTimerActive", null ],
        [ "xTimerStart", "group___timer.html#xTimerStart", null ],
        [ "xTimerStop", "group___timer.html#xTimerStop", null ],
        [ "xTimerChangePeriod", "group___timer.html#xTimerChangePeriod", null ],
        [ "xTimerDelete", "group___timer.html#xTimerDelete", null ],
        [ "xTimerReset", "group___timer.html#xTimerReset", null ],
        [ "xTimerStartFromISR", "group___timer.html#xTimerStartFromISR", null ],
        [ "xTimerStopFromISR", "group___timer.html#xTimerStopFromISR", null ],
        [ "xTimerChangePeriodFromISR", "group___timer.html#xTimerChangePeriodFromISR", null ],
        [ "xTimerResetFromISR", "group___timer.html#xTimerResetFromISR", null ]
      ] ],
      [ "Co-routines", "group___co_routines.html", [
        [ "xCoRoutineCreate", "group___co_routines.html#xCoRoutineCreate", null ],
        [ "vCoRoutineSchedule", "group___co_routines.html#vCoRoutineSchedule", null ],
        [ "crSTART", "group___co_routines.html#crSTART", null ],
        [ "crEND", "group___co_routines.html#crEND", null ],
        [ "crDELAY", "group___co_routines.html#crDELAY", null ],
        [ "crQUEUE_SEND", "group___co_routines.html#crQUEUE_SEND", null ],
        [ "crQUEUE_RECEIVE", "group___co_routines.html#crQUEUE_RECEIVE", null ],
        [ "crQUEUE_SEND_FROM_ISR", "group___co_routines.html#crQUEUE_SEND_FROM_ISR", null ],
        [ "crQUEUE_RECEIVE_FROM_ISR", "group___co_routines.html#crQUEUE_RECEIVE_FROM_ISR", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "corCoRoutineControlBlock", "structcor_co_routine_control_block.html", null ],
      [ "QueueDefinition", "struct_queue_definition.html", null ],
      [ "tskTaskControlBlock", "structtsk_task_control_block.html", null ],
      [ "xLIST", "structx_l_i_s_t.html", null ],
      [ "xLIST_ITEM", "structx_l_i_s_t___i_t_e_m.html", null ],
      [ "xMEMORY_REGION", "structx_m_e_m_o_r_y___r_e_g_i_o_n.html", null ],
      [ "xMINI_LIST_ITEM", "structx_m_i_n_i___l_i_s_t___i_t_e_m.html", null ],
      [ "xTASK_PARAMTERS", "structx_t_a_s_k___p_a_r_a_m_t_e_r_s.html", null ],
      [ "xTIME_OUT", "structx_t_i_m_e___o_u_t.html", null ]
    ] ],
    [ "Data Structure Index", "classes.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

